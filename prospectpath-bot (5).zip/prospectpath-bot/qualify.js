// The qualification flow itself — edit QUESTIONS to change what the bot
// asks. Each question's answer is stored under its `key`.
const store = require('./store');

const WELCOME = "Bonjour 👋 Merci de nous contacter ! Je vais vous poser quelques questions rapides pour mieux vous orienter.";

const QUESTIONS = [
  { key: 'besoin', text: "Quel est votre besoin ou ce qui vous intéresse ?" },
  { key: 'ville', text: "Dans quelle ville êtes-vous basé(e) ?" },
  { key: 'budget', text: "Avez-vous une idée de budget pour ce projet ?" },
];

const CLOSING = "Merci ! Un membre de notre équipe va vous recontacter très bientôt. 🙏";

// Returns { reply, done } — `reply` is the text to send back,
// `done` is true once the lead has just been finalized.
async function handleMessage({ channel, contactId, contactName, text }) {
  let session = store.getSession(channel, contactId);

  if (!session) {
    session = { step: 0, answers: {} };
    await store.setSession(channel, contactId, session);
    return { reply: WELCOME + '\n\n' + QUESTIONS[0].text, done: false };
  }

  // Record the answer to the question we just asked.
  if (session.step < QUESTIONS.length) {
    const q = QUESTIONS[session.step];
    session.answers[q.key] = (text || '').trim();
    session.step += 1;
  }

  if (session.step < QUESTIONS.length) {
    await store.setSession(channel, contactId, session);
    return { reply: QUESTIONS[session.step].text, done: false };
  }

  // All questions answered — finalize the lead.
  const now = new Date().toISOString();
  await store.addLead({
    id: channel + '_' + contactId + '_' + Date.now(),
    channel,               // 'whatsapp' | 'messenger'
    contactId,
    contactName: contactName || '',
    answers: session.answers,
    createdAt: now,
  });
  await store.clearSession(channel, contactId);
  return { reply: CLOSING, done: true };
}

module.exports = { handleMessage, QUESTIONS };
