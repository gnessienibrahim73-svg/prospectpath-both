# ProspectPath Bot

Petit serveur qui reçoit les messages WhatsApp (Cloud API) et Facebook Messenger, pose 3 questions de qualification, puis garde les prospects qualifiés prêts à être récupérés par l'app **ProspectPath** (bouton 🔄 dans la barre du haut).

## 1. Déployer gratuitement sur Render

1. Poussez ce dossier sur un dépôt GitHub (comme pour ProspectPath).
2. Sur [render.com](https://render.com), **New → Web Service**, connectez le dépôt.
3. Réglages :
   - Build command : `npm install`
   - Start command : `npm start`
   - Plan : Free
4. Dans l'onglet **Environment**, ajoutez toutes les variables de `.env.example` (avec vos vraies valeurs — voir étape 2 ci-dessous).
5. Déployez. Notez l'URL donnée par Render, par ex. `https://prospectpath-bot.onrender.com`.

> Le plan gratuit de Render "s'endort" après 15 min d'inactivité et met quelques secondes à se réveiller au message suivant — normal, pas un bug.

## 2. Récupérer vos identifiants Meta

Dans [developers.facebook.com](https://developers.facebook.com), sur votre app :

- **WhatsApp → API Setup** : `WHATSAPP_TOKEN` (token permanent, pas le temporaire 24h) et `WHATSAPP_PHONE_NUMBER_ID`.
- **Messenger → Paramètres** : `PAGE_ACCESS_TOKEN` généré pour votre page.
- `WHATSAPP_VERIFY_TOKEN` et `MESSENGER_VERIFY_TOKEN` : inventez-les vous-même (n'importe quelle phrase secrète).
- `SYNC_API_KEY` : inventez une longue clé secrète, elle protège l'accès à vos leads.

## 3. Configurer les webhooks côté Meta

Pour WhatsApp comme pour Messenger, dans la configuration du webhook de votre app Meta :

- **URL de rappel** : `https://VOTRE-URL-RENDER.onrender.com/webhooks/whatsapp` (ou `/webhooks/messenger`)
- **Jeton de vérification** : la même valeur que `WHATSAPP_VERIFY_TOKEN` (ou `MESSENGER_VERIFY_TOKEN`)
- Abonnez-vous au champ `messages`.

Meta enverra une requête de vérification automatiquement — si tout est bien configuré, ça passe au vert directement.

## 4. Connecter ProspectPath

Dans l'app ProspectPath, appuyez sur l'icône 🔄 dans la barre du haut, entrez :
- l'URL Render
- la `SYNC_API_KEY`

puis **Synchroniser maintenant**. Les prospects qualifiés apparaissent à l'étape "Contacté", avec leurs réponses dans les notes. Vous pouvez resynchroniser à tout moment — seuls les nouveaux leads sont importés.

## Personnaliser les questions

Modifiez le tableau `QUESTIONS` dans `qualify.js`.

## Limite du plan gratuit

Les données (`data.json`) vivent sur le disque du service Render. Elles survivent tant que le service n'est pas redéployé/recréé. Pour un usage sérieux à plus gros volume, une vraie base de données serait plus sûre — dites-le-moi si vous voulez que je fasse cette évolution plus tard.
