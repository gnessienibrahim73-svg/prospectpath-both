require('dotenv').config();
const express = require('express');
const whatsapp = require('./channels/whatsapp');
const messenger = require('./channels/messenger');
const store = require('./store');

const app = express();
app.use(express.json());

app.get('/', (req, res) => res.send('ProspectPath bot is running.'));

// ----- WhatsApp Cloud API -----
app.get('/webhooks/whatsapp', whatsapp.verify);
app.post('/webhooks/whatsapp', whatsapp.receive);

// ----- Facebook Messenger -----
app.get('/webhooks/messenger', messenger.verify);
app.post('/webhooks/messenger', messenger.receive);

// ----- Sync API for ProspectPath -----
// GET /api/leads?since=<ISO timestamp>
// Header: Authorization: Bearer <SYNC_API_KEY>
app.get('/api/leads', (req, res) => {
  const auth = req.headers.authorization || '';
  const key = auth.replace('Bearer ', '');
  if (key !== process.env.SYNC_API_KEY) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  const leads = store.getLeadsSince(req.query.since);
  res.json({ leads, serverTime: new Date().toISOString() });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`ProspectPath bot listening on port ${PORT}`));
